# -*- coding: utf-8 -*-
"""
RakUpdater.pyw — ตัวอัปเดตแยกของ RakComSoft 2026
────────────────────────────────────────────────────────────
ทำงานหลังโปรแกรมหลักปิด (เพราะ Windows replace ไฟล์ที่กำลังเปิดอยู่ไม่ได้)

ลำดับงาน:
  1) อ่าน update_job.json (โปรแกรมหลักเขียนไว้)
  2) รอโปรแกรมหลักปิดสนิท
  3) Backup ไฟล์เดิม  → /Backup/<วันที่>/
  4) แตก update.zip ทับ (ยกเว้น *.db)
  5) สำเร็จ → เปิดโปรแกรมใหม่ | ล้มเหลว → Rollback แล้วเปิดเวอร์ชันเดิม
  6) บันทึก log ทุกขั้นตอน

เรียกโดยโปรแกรมหลัก:  pythonw RakUpdater.pyw
"""
import os, sys, json, time, subprocess
import tkinter as tk
from tkinter import ttk

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import updater  # engine เดียวกัน

JOB = os.path.join(HERE, "update_job.json")

DARK_BG = "#0d1117"; CARD = "#161b22"; TEXT = "#e6edf3"
ACCENT  = "#2dd4bf"; MUTED = "#8b949e"; RED = "#ff6b6b"; GREEN = "#3fb950"


class UpdaterUI:
    def __init__(self, root, job):
        self.root = root; self.job = job
        root.title("RakComSoft — กำลังอัปเดต")
        root.configure(bg=DARK_BG); root.geometry("480x300")
        root.resizable(False, False)
        try: root.attributes("-topmost", True)
        except Exception: pass

        tk.Frame(root, bg=ACCENT, height=4).pack(fill=tk.X)
        tk.Label(root, text="⬆  กำลังอัปเดต RakComSoft 2026", font=("Segoe UI", 15, "bold"),
                 bg=DARK_BG, fg=TEXT).pack(pady=(18, 4))
        self.ver = tk.Label(root, text=f"v{job.get('from_version','?')}  →  {job.get('new_version','?')}",
                            font=("Segoe UI", 11), bg=DARK_BG, fg=MUTED)
        self.ver.pack()

        box = tk.Frame(root, bg=CARD); box.pack(fill=tk.X, padx=24, pady=18)
        self.status = tk.Label(box, text="กำลังเตรียมการ...", font=("Segoe UI", 11),
                               bg=CARD, fg=TEXT, anchor="w", justify="left", wraplength=410)
        self.status.pack(fill=tk.X, padx=14, pady=(14, 6))
        self.pb = ttk.Progressbar(box, mode="indeterminate", length=410)
        self.pb.pack(padx=14, pady=(0, 14)); self.pb.start(12)

        self.detail = tk.Label(root, text="กรุณาอย่าปิดหน้าต่างนี้ระหว่างอัปเดต",
                               font=("Segoe UI", 9), bg=DARK_BG, fg=MUTED)
        self.detail.pack(side=tk.BOTTOM, pady=10)

        root.after(400, self.run)

    def set_status(self, txt, color=TEXT):
        self.status.config(text=txt, fg=color); self.root.update_idletasks()

    def run(self):
        ad = self.job.get("app_dir", HERE)
        zip_path = self.job.get("zip", "")
        backup_dir = None
        try:
            # 1) รอโปรแกรมหลักปิด
            self.set_status("กำลังรอโปรแกรมหลักปิด...")
            self._wait_main_closed(self.job.get("pid"))

            if not zip_path or not os.path.exists(zip_path):
                raise IOError("ไม่พบไฟล์อัปเดต (update.zip)")

            # 2) Backup
            self.set_status("กำลังสำรองไฟล์เดิม (Backup)...")
            backup_dir = updater.backup_current()
            updater.log(f"BACKUP → {backup_dir}", ad)

            # 3) Apply
            self.set_status("กำลังติดตั้งอัปเดต...")
            n = updater.apply_update(zip_path, ad)
            updater.log(f"APPLY OK: {n} ไฟล์ | {self.job.get('from_version')} → {self.job.get('new_version')}", ad)

            # 4) สำเร็จ
            self.pb.stop(); self.pb.config(mode="determinate", value=100)
            self.set_status(f"✅ อัปเดตสำเร็จ (เวอร์ชัน {self.job.get('new_version')})\nกำลังเปิดโปรแกรมใหม่...", GREEN)
            self.root.update_idletasks(); time.sleep(1.2)
            self._cleanup(zip_path)
            self._relaunch(); self.root.after(300, self.root.destroy)

        except Exception as e:
            updater.log(f"ERROR: {e}", ad)
            # Rollback
            self.pb.stop()
            if backup_dir and os.path.isdir(backup_dir):
                self.set_status(f"⚠️ อัปเดตล้มเหลว: {e}\nกำลังคืนเวอร์ชันเดิม (Rollback)...", RED)
                self.root.update_idletasks()
                try:
                    r = updater.rollback(backup_dir, ad)
                    updater.log(f"ROLLBACK OK: {r} ไฟล์ จาก {backup_dir}", ad)
                    self.set_status("คืนเวอร์ชันเดิมแล้ว กำลังเปิดโปรแกรม...", MUTED)
                except Exception as re:
                    updater.log(f"ROLLBACK FAILED: {re}", ad)
                    self.set_status(f"❌ Rollback ล้มเหลว: {re}\nกรุณาคืนไฟล์จาก {backup_dir} ด้วยตนเอง", RED)
            else:
                self.set_status(f"❌ อัปเดตล้มเหลว: {e}", RED)
            self.root.update_idletasks(); time.sleep(2.0)
            self._cleanup(zip_path)
            self._relaunch(); self.root.after(500, self.root.destroy)

    def _wait_main_closed(self, pid, timeout=20):
        """รอ process โปรแกรมหลักปิด (ถ้าหา psutil ไม่เจอ ใช้หน่วงเวลาแทน)"""
        if not pid:
            time.sleep(2.0); return
        try:
            import ctypes
            PROCESS_QUERY = 0x1000
            k = ctypes.windll.kernel32
            t0 = time.time()
            while time.time() - t0 < timeout:
                h = k.OpenProcess(PROCESS_QUERY, False, int(pid))
                if not h:
                    return                       # ปิดแล้ว
                exit_code = ctypes.c_ulong(0)
                k.GetExitCodeProcess(h, ctypes.byref(exit_code))
                k.CloseHandle(h)
                if exit_code.value != 259:       # 259 = STILL_ACTIVE
                    return
                time.sleep(0.4)
        except Exception:
            time.sleep(2.5)

    def _relaunch(self):
        ad = self.job.get("app_dir", HERE)
        launcher = os.path.join(ad, self.job.get("launcher", "Rakcomsoft.bat"))
        main = os.path.join(ad, self.job.get("main_script", "rakcomsoft.py"))
        try:
            if os.path.exists(launcher):
                os.startfile(launcher)
            else:
                pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
                subprocess.Popen([pyw if os.path.exists(pyw) else sys.executable, main], cwd=ad)
            updater.log("RELAUNCH โปรแกรมหลัก", ad)
        except Exception as e:
            updater.log(f"RELAUNCH FAILED: {e}", ad)

    def _cleanup(self, zip_path):
        for p in (zip_path, JOB):
            try:
                if p and os.path.exists(p): os.remove(p)
            except Exception: pass


def main():
    if not os.path.exists(JOB):
        return
    try:
        with open(JOB, encoding="utf-8") as f:
            job = json.load(f)
    except Exception:
        return
    root = tk.Tk()
    UpdaterUI(root, job)
    root.mainloop()


if __name__ == "__main__":
    main()
