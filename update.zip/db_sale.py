"""
db_sale.py — RakComSoft 2026
Sales Query Layer (READ-ONLY)
Session 9 — Incremental Refactor

รวม SELECT queries สำหรับ sales / sale_items / report / dashboard / EOD
ไม่มี INSERT / UPDATE / DELETE ใดๆ ทั้งสิ้น
ไม่มี tkinter / UI ใดๆ
Import ได้อิสระจากทุก module

Dependencies: helpers.get_db (sqlite3 only)

✅ Session 9 เพิ่ม (ReportTab dynamic filter layer):
    - get_customer_names()
    - get_report_bills()
    - get_report_bill_ids_by_product()
    - get_report_top_products()
    - get_report_daily_summary()

❌ ยังไม่รวม:
    - _save_sale / void_sale / payment flow
    - INSERT sale_items / INSERT returns
    - stock movement write path
    - transaction / commit logic
"""

from helpers import get_db


# ══ SINGLE SALE LOOKUP ══════════════════════════════════════

def get_sale(sale_id: int) -> dict | None:
    """
    ดึง sale ตาม ID
    Returns: dict หรือ None ถ้าไม่พบ

    ใช้แทน inline query บรรทัดที่:
      707 — print_receipt
    """
    conn = get_db()
    row = conn.execute(
        "SELECT * FROM sales WHERE id=?",
        (sale_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_sale_with_customer(sale_id: int) -> dict | None:
    """
    ดึง sale พร้อม customer name (LEFT JOIN)
    Returns: dict หรือ None ถ้าไม่พบ

    ใช้แทน inline query บรรทัดที่:
      3658 — ReturnTab._load_bill
    """
    conn = get_db()
    row = conn.execute(
        "SELECT s.*, c.name as cn "
        "FROM sales s LEFT JOIN customers c ON s.customer_id=c.id "
        "WHERE s.id=?",
        (sale_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None


# ══ SALE ITEMS LOOKUP ═══════════════════════════════════════

def get_sale_items(sale_id: int) -> list[dict]:
    """
    ดึงรายการสินค้าในบิลตาม sale_id
    Returns: list[dict]

    ใช้แทน inline query บรรทัดที่:
      708  — print_receipt
      3661 — ReturnTab._load_bill
      4332 — ReportTab._show_items
    """
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM sale_items WHERE sale_id=?",
        (sale_id,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_sale_item_product_id(item_id: int) -> int | None:
    """
    ดึง product_id จาก sale_items ตาม item.id
    Returns: int หรือ None ถ้าไม่พบ

    ใช้แทน inline query บรรทัดที่:
      3717 — ReturnTab._do_return
    """
    conn = get_db()
    row = conn.execute(
        "SELECT product_id FROM sale_items WHERE id=?",
        (item_id,)
    ).fetchone()
    conn.close()
    return row["product_id"] if row else None


# ══ CUSTOMER SALE HISTORY ════════════════════════════════════

def get_sales_by_customer(customer_id: int, limit: int = 50) -> list[dict]:
    """
    ดึงประวัติการซื้อของลูกค้า เรียงล่าสุดก่อน
    Returns: list[dict]

    ใช้แทน inline query บรรทัดที่:
      3460 — CustomerTab._hist
    """
    conn = get_db()
    sql = (
        "SELECT * FROM sales WHERE customer_id=? "
        "ORDER BY sale_date DESC"
    )
    params: list = [customer_id]
    if limit > 0:
        sql += f" LIMIT {limit}"
        params.append(limit)
    # Note: LIMIT ต้องอยู่ใน sql ไม่ใช่ params สำหรับ SQLite
    sql_final = (
        "SELECT * FROM sales WHERE customer_id=? "
        f"ORDER BY sale_date DESC{f' LIMIT {limit}' if limit > 0 else ''}"
    )
    rows = conn.execute(sql_final, [customer_id]).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_customer_debt(customer_id: int) -> float:
    """
    ★ DELEGATES to db_receivable.get_customer_outstanding_balance()
    Single source of truth — do NOT duplicate debt formula here.

    ใช้แทน inline query บรรทัดที่:
      1831 — SaleTab (debt check ก่อนบันทึกเงินเชื่อ)
    """
    from db_receivable import get_customer_outstanding_balance
    return get_customer_outstanding_balance(customer_id)


# ══ DASHBOARD KPI QUERIES ═══════════════════════════════════

def get_today_sales_kpi(date_str: str) -> dict:
    """
    ดึง KPI ยอดขายประจำวัน:
      - total_net : ยอดขายรวม (SUM net)
      - total_bills: จำนวนบิล
      - total_cost : ต้นทุนรวม

    date_str รูปแบบ 'YYYY-MM-DD'
    Returns: dict(total_net, total_bills, total_cost)

    ใช้แทน inline query บรรทัดที่:
      3829-3831 — DashboardTab._refresh
    """
    conn = get_db()
    t_sales = conn.execute(
        "SELECT COALESCE(SUM(net),0) FROM sales WHERE date(sale_date)=?",
        (date_str,)
    ).fetchone()[0]
    t_bills = conn.execute(
        "SELECT COUNT(*) FROM sales WHERE date(sale_date)=?",
        (date_str,)
    ).fetchone()[0]
    t_cost = conn.execute(
        "SELECT COALESCE(SUM(si.qty*si.cost),0) "
        "FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        "WHERE date(s.sale_date)=?",
        (date_str,)
    ).fetchone()[0]
    conn.close()
    return {
        "total_net":   float(t_sales),
        "total_bills": int(t_bills),
        "total_cost":  float(t_cost),
    }


def get_daily_sales_range(date_from: str, date_to: str) -> list[dict]:
    """
    ดึงยอดขายรายวันในช่วงวันที่
    Returns: list[dict(d, total)] เรียงตาม d

    ใช้แทน inline query บรรทัดที่:
      3843 — DashboardTab._refresh (daily bar chart)
    """
    conn = get_db()
    rows = conn.execute(
        "SELECT date(sale_date) as d, SUM(net) as total "
        "FROM sales WHERE date(sale_date) BETWEEN ? AND ? "
        "GROUP BY date(sale_date) ORDER BY d",
        (date_from, date_to)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_top_products(date_from: str, date_to: str, limit: int = 5) -> list[dict]:
    """
    ดึง top สินค้าขายดีในช่วงวันที่
    Returns: list[dict(name, tq, ts)] เรียงตาม tq DESC

    ใช้แทน inline query บรรทัดที่:
      3848 — DashboardTab._refresh (top 5 chart)
    """
    conn = get_db()
    rows = conn.execute(
        "SELECT si.name, SUM(si.qty) tq, SUM(si.subtotal) ts "
        "FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        "WHERE date(s.sale_date) BETWEEN ? AND ? "
        f"GROUP BY si.product_id,si.name ORDER BY tq DESC LIMIT {limit}",
        (date_from, date_to)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ══ EOD (End-of-Day) QUERIES ════════════════════════════════

def get_eod_payment_summary(date_from: str, date_to: str) -> list[dict]:
    """
    สรุปยอดขายแยกตาม payment_method
    Returns: list[dict(payment_method, s, c)]

    ใช้แทน inline query บรรทัดที่:
      5002 — EODTab._load (ส่วน pay_map)
      5083 — EODTab._print
    """
    conn = get_db()
    rows = conn.execute(
        "SELECT payment_method, SUM(net) s, COUNT(*) c "
        "FROM sales WHERE date(sale_date) BETWEEN ? AND ? "
        "GROUP BY payment_method",
        (date_from, date_to)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_eod_summary(date_from: str, date_to: str) -> dict:
    """
    สรุปยอดขาย: gross, disc, promo_disc, net
    Returns: dict(gross, disc, promo, net)

    ใช้แทน inline query บรรทัดที่:
      5024 — EODTab._load
      5088 — EODTab._print
    """
    conn = get_db()
    row = conn.execute(
        "SELECT COALESCE(SUM(total),0) gross, "
        "COALESCE(SUM(discount),0) disc, "
        "COALESCE(SUM(promo_disc),0) promo, "
        "COALESCE(SUM(net),0) net "
        "FROM sales WHERE date(sale_date) BETWEEN ? AND ?",
        (date_from, date_to)
    ).fetchone()
    conn.close()
    return dict(row) if row else {"gross": 0, "disc": 0, "promo": 0, "net": 0}


def get_eod_cost(date_from: str, date_to: str) -> float:
    """
    คำนวณต้นทุนรวมในช่วงวันที่ (จาก sale_items JOIN sales)
    Returns: float

    ใช้แทน inline query บรรทัดที่:
      5036 — EODTab._load
      5096 — EODTab._print
    """
    conn = get_db()
    row = conn.execute(
        "SELECT COALESCE(SUM(si.qty * si.cost),0) cost "
        "FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        "WHERE date(s.sale_date) BETWEEN ? AND ?",
        (date_from, date_to)
    ).fetchone()
    conn.close()
    return float(row["cost"]) if row else 0.0


def get_eod_debt_summary(date_from: str, date_to: str) -> dict:
    """
    ★ DELEGATES to db_receivable.get_total_debt_summary()
    Single source of truth — do NOT duplicate debt formula here.

    ใช้แทน inline query บรรทัดที่:
      5059-5069 — EODTab._load
    """
    from db_receivable import get_total_debt_summary
    return get_total_debt_summary(date_from=date_from, date_to=date_to)


# ══ REPORT EXPORT DATA ══════════════════════════════════════

def get_report_data(date_from: str, date_to: str) -> dict:
    """
    ดึงข้อมูลสำหรับ export report (ReportTab._report_data)
    Returns: dict(sales, items, top)

    หมายเหตุ: prods ยังคง query ใน rakcomsoft.py ผ่าน db_product
    ใช้แทน inline query บรรทัดที่:
      4340-4342 — ReportTab._report_data
    """
    conn = get_db()
    sales = conn.execute(
        "SELECT s.*, c.name as cn FROM sales s "
        "LEFT JOIN customers c ON s.customer_id=c.id "
        "WHERE date(sale_date) BETWEEN ? AND ? "
        "AND COALESCE(s.status,'normal') != 'void' "
        "ORDER BY sale_date DESC",
        (date_from, date_to)
    ).fetchall()
    items = conn.execute(
        "SELECT si.*, s.sale_date as sdate "
        "FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        "WHERE date(s.sale_date) BETWEEN ? AND ? "
        "AND COALESCE(s.status,'normal') != 'void'",
        (date_from, date_to)
    ).fetchall()
    top = conn.execute(
        "SELECT si.name, SUM(si.qty) tq, SUM(si.subtotal) ts, "
        "SUM((si.price-si.cost)*si.qty) tp "
        "FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        "WHERE date(s.sale_date) BETWEEN ? AND ? "
        "AND COALESCE(s.status,'normal') != 'void' "
        "GROUP BY si.product_id,si.name ORDER BY tq DESC",
        (date_from, date_to)
    ).fetchall()
    conn.close()
    return {
        "sales": [dict(r) for r in sales],
        "items": [dict(r) for r in items],
        "top":   [dict(r) for r in top],
    }


# ══ REPORT FILTER HELPERS (Session 9) ══════════════════════

def _build_report_where(
    d0: str,
    d1: str,
    customer: str | None = None,
    payment: str | None = None,
    exclude_void: bool = False,
) -> tuple[str, list]:
    """
    Internal helper — สร้าง WHERE clause + params สำหรับ ReportTab
    d0, d1   : 'YYYY-MM-DD' หรือ Thai date (dd/mm/YYYY) ก็ได้
    customer : ชื่อลูกค้า หรือ None / "ทั้งหมด" → ไม่กรอง
    payment  : payment_method ('cash','qr','credit','debt','mixed')
               หรือ None / "ทั้งหมด" → ไม่กรอง
    exclude_void : True → ไม่นับบิลที่ยกเลิก (status='void')
                   ใช้กับยอดสรุป/สินค้าขายดี/กำไรรายวัน
                   (รายการบิลตั้ง False เพื่อยังแสดงบิล void เป็น ✖)
    Returns  : (where_str, params_list)

    ❗ ไม่ export โดยตรง — ใช้ภายใน db_sale.py เท่านั้น
    """
    where = "date(s.sale_date) BETWEEN ? AND ?"
    params: list = [d0, d1]
    if customer and customer != "ทั้งหมด":
        where += " AND c.name=?"
        params.append(customer)
    if payment and payment != "ทั้งหมด":
        where += " AND s.payment_method=?"
        params.append(payment)
    if exclude_void:
        where += " AND COALESCE(s.status,'normal') != 'void'"
    return where, params


def get_customer_names() -> list[str]:
    """
    ดึงรายชื่อลูกค้าทั้งหมด เรียงตามชื่อ
    Returns: list[str] — ใช้เป็น dropdown values ใน ReportTab

    ใช้แทน inline query บรรทัดที่:
      4178-4181 — ReportTab._refresh_cust_list
    """
    conn = get_db()
    rows = conn.execute(
        "SELECT name FROM customers ORDER BY name"
    ).fetchall()
    conn.close()
    return [r["name"] for r in rows]


def get_report_bills(
    d0: str,
    d1: str,
    customer: str | None = None,
    payment: str | None = None,
) -> tuple[list[dict], dict]:
    """
    ดึงรายการบิล + cost_map ในช่วงวันที่ พร้อม filter ครบ
    Returns: (sales: list[dict], cost_map: dict[sale_id -> float])

    cost_map = {sale_id: total_cost} — คำนวณจาก sale_items
    ใช้แทน inline query บรรทัดที่:
      4210-4227 — ReportTab.load() (bill list + cost per bill)
    """
    where, params = _build_report_where(d0, d1, customer, payment)
    conn = get_db()

    sales = conn.execute(
        f"SELECT s.*, c.name as cn FROM sales s "
        f"LEFT JOIN customers c ON s.customer_id=c.id "
        f"WHERE {where} ORDER BY s.sale_date DESC",
        params
    ).fetchall()

    cost_rows = conn.execute(
        f"SELECT si.sale_id, SUM(si.cost*si.qty) tc "
        f"FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        f"LEFT JOIN customers c ON s.customer_id=c.id "
        f"WHERE {where} GROUP BY si.sale_id",
        params
    ).fetchall()

    conn.close()
    cost_map = {r["sale_id"]: r["tc"] or 0 for r in cost_rows}
    return [dict(r) for r in sales], cost_map


def get_report_bill_ids_by_product(
    d0: str,
    d1: str,
    prod_name: str,
    customer: str | None = None,
    payment: str | None = None,
) -> set[int]:
    """
    ดึง sale_id ที่มีสินค้าตรงกับ prod_name (LIKE)
    Returns: set[int] — ใช้ post-filter sales list

    ใช้แทน inline query บรรทัดที่:
      4232-4239 — ReportTab.load() (filter by product name)
    """
    if not prod_name or not prod_name.strip():
        return set()
    where, params = _build_report_where(d0, d1, customer, payment)
    conn = get_db()
    rows = conn.execute(
        f"SELECT DISTINCT si.sale_id FROM sale_items si "
        f"JOIN sales s ON si.sale_id=s.id "
        f"LEFT JOIN customers c ON s.customer_id=c.id "
        f"WHERE {where} AND si.name LIKE ?",
        params + [f"%{prod_name.strip()}%"]
    ).fetchall()
    conn.close()
    return {r["sale_id"] for r in rows}


def get_report_top_products(
    d0: str,
    d1: str,
    customer: str | None = None,
    payment: str | None = None,
    limit: int = 20,
) -> list[dict]:
    """
    ดึง top สินค้า (filtered) สำหรับ ReportTab top-product tree
    Returns: list[dict(name, tq, ts, tc)] เรียงตาม tq DESC

    ใช้แทน inline query บรรทัดที่:
      4242-4248 — ReportTab.load() (top products with cost)
    """
    where, params = _build_report_where(d0, d1, customer, payment, exclude_void=True)
    conn = get_db()
    rows = conn.execute(
        f"SELECT si.name, SUM(si.qty) tq, SUM(si.subtotal) ts, "
        f"SUM(si.cost*si.qty) tc "
        f"FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        f"LEFT JOIN customers c ON s.customer_id=c.id "
        f"WHERE {where} GROUP BY si.product_id, si.name "
        f"ORDER BY tq DESC LIMIT {limit}",
        params
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_report_daily_summary(
    d0: str,
    d1: str,
    customer: str | None = None,
    payment: str | None = None,
) -> tuple[list[dict], dict]:
    """
    ดึงสรุปรายวัน + daily_cost_map สำหรับ ReportTab profit tree
    Returns: (daily: list[dict(d, bills, net)], daily_cost: dict[d -> float])

    daily_cost = {date_str: total_cost}
    ใช้แทน inline query บรรทัดที่:
      4252-4267 — ReportTab.load() (daily summary + daily cost)
    """
    where, params = _build_report_where(d0, d1, customer, payment, exclude_void=True)
    conn = get_db()

    daily = conn.execute(
        f"SELECT date(s.sale_date) as d, COUNT(*) bills, SUM(s.net) net "
        f"FROM sales s LEFT JOIN customers c ON s.customer_id=c.id "
        f"WHERE {where} GROUP BY date(s.sale_date) ORDER BY d DESC",
        params
    ).fetchall()

    dc_rows = conn.execute(
        f"SELECT date(s.sale_date) as d, SUM(si.cost*si.qty) tc "
        f"FROM sale_items si JOIN sales s ON si.sale_id=s.id "
        f"LEFT JOIN customers c ON s.customer_id=c.id "
        f"WHERE {where} GROUP BY date(s.sale_date)",
        params
    ).fetchall()

    conn.close()
    daily_cost = {r["d"]: r["tc"] or 0 for r in dc_rows}
    return [dict(r) for r in daily], daily_cost


# ══ PRODUCT SALES REPORT (รายการขายสินค้า — สินค้า×สต็อก) ═══════
def get_product_sales_report(
    d0: str, d1: str,
    customer: str | None = None,
    payment: str | None = None,
    category: str | None = None,
    search: str = "",
    sort: str = "qty",
    view: str = "all",
    limit: int = 3000,
) -> list[dict]:
    """รวมยอดขายระดับ 'สินค้า' ในช่วงวันที่ + JOIN สต็อก/หมวด/หน่วย
    sort: qty|profit|stock|name|code   view: all|low (สต็อก<=ขั้นต่ำ)
    ไม่นับบิลที่ยกเลิก — aggregate (GROUP BY product) จึง bounded ตามจำนวนสินค้าที่ขายจริง
    """
    where = ("date(s.sale_date) BETWEEN ? AND ? "
             "AND COALESCE(s.status,'normal') != 'void'")
    params: list = [d0, d1]
    if customer and customer != "ทั้งหมด":
        where += " AND c.name=?"; params.append(customer)
    if payment and payment != "ทั้งหมด":
        where += " AND s.payment_method=?"; params.append(payment)
    if category and category != "ทั้งหมด":
        where += " AND p.category=?"; params.append(category)
    if search:
        where += " AND (si.name LIKE ? OR p.barcode LIKE ?)"
        params += [f"%{search}%", f"%{search}%"]

    sql = (
        "SELECT si.product_id AS pid, p.barcode AS code, "
        "       COALESCE(p.category,'') AS category, "
        "       COALESCE(p.name, si.name) AS name, "
        "       COALESCE(p.unit,'') AS unit, "
        "       COALESCE(p.stock,0) AS stock, COALESCE(p.min_stock,0) AS min_stock, "
        "       SUM(si.qty) AS qty, SUM(si.subtotal) AS sales, "
        "       SUM(si.cost*si.qty) AS cost, MAX(s.sale_date) AS last_sold "
        "FROM sale_items si "
        "JOIN sales s ON s.id=si.sale_id "
        "LEFT JOIN customers c ON c.id=s.customer_id "
        "LEFT JOIN products p ON p.id=si.product_id "
        f"WHERE {where} GROUP BY si.product_id, si.name"
    )
    conn = get_db()
    rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    conn.close()

    for r in rows:
        r["profit"] = (r["sales"] or 0) - (r["cost"] or 0)

    if view == "low":
        rows = [r for r in rows if (r["stock"] or 0) <= (r["min_stock"] or 0)]

    _keys = {
        "qty":    (lambda r: r["qty"]    or 0, True),
        "profit": (lambda r: r["profit"] or 0, True),
        "stock":  (lambda r: r["stock"]  or 0, False),
        "name":   (lambda r: (r["name"]  or "").lower(), False),
        "code":   (lambda r: (r["code"]  or ""), False),
    }
    kf, rev = _keys.get(sort, _keys["qty"])
    rows.sort(key=kf, reverse=rev)
    return rows[:limit]


def get_product_sale_detail(d0: str, d1: str, product_id: int, limit: int = 500) -> list[dict]:
    """Drill-down: บิลทั้งหมดที่ขายสินค้าตัวนี้ในช่วงวันที่ (ไม่นับบิลยกเลิก)"""
    conn = get_db()
    rows = conn.execute(
        "SELECT s.id AS sale_id, s.sale_date, c.name AS cust, "
        "       si.qty, si.price, si.subtotal, s.payment_method "
        "FROM sale_items si JOIN sales s ON s.id=si.sale_id "
        "LEFT JOIN customers c ON c.id=s.customer_id "
        "WHERE si.product_id=? AND date(s.sale_date) BETWEEN ? AND ? "
        "      AND COALESCE(s.status,'normal') != 'void' "
        "ORDER BY s.sale_date DESC LIMIT ?",
        (product_id, d0, d1, limit)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ══ SELF-TEST ════════════════════════════════════════════════
if __name__ == "__main__":
    print("=== db_sale.py self-test ===")
    print("ฟังก์ชันที่ export:")
    fns = [
        # Session 8
        "get_sale",
        "get_sale_with_customer",
        "get_sale_items",
        "get_sale_item_product_id",
        "get_sales_by_customer",
        "get_customer_debt",
        "get_today_sales_kpi",
        "get_daily_sales_range",
        "get_top_products",
        "get_eod_payment_summary",
        "get_eod_summary",
        "get_eod_cost",
        "get_eod_debt_summary",
        "get_report_data",
        # Session 9
        "get_customer_names",
        "get_report_bills",
        "get_report_bill_ids_by_product",
        "get_report_top_products",
        "get_report_daily_summary",
    ]
    import db_sale as _self
    for fn in fns:
        status = "✅" if hasattr(_self, fn) else "❌"
        print(f"  {status} {fn}")
    print("\n⚠️  get_customer_debt / get_eod_debt_summary DELEGATE to db_receivable")
    print("     (single source of truth — ไม่มี legacy formula ใน db_sale แล้ว)")
    print("\n⚠️  การทดสอบ query ต้องการ DB จริง")
    print("     ทดสอบผ่าน rakcomsoft.py ตามปกติ")
    print("=== DONE ===")
