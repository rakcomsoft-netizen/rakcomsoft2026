# =============================================================================
# RakComSoft 2026 — db_receivable.py  (v6 — SINGLE SOURCE OF TRUTH)
#
# REAL SCHEMA (confirmed):
#   DB        : via helpers.get_db() — same connection as entire app
#   sales     : id, sale_date, total, discount, paid(REAL), change_amt,
#               note, promo_disc, net, customer_id, payment_method
#   customers : id, code, name, phone, points, total_spent, created_at
#
# DEBT DETECTION (confirmed from debug):
#   payment_method IN ('debt','credit')
#   OR note LIKE '%เงิน ซื้อ%'
#   outstanding = net - paid - SUM(receivable_payments.amount)
#   customer_id = 0  →  "ลูกค้าทั่วไป"
#
# THIS FILE IS THE SINGLE SOURCE OF TRUTH FOR ALL DEBT CALCULATIONS.
# db_sale.get_customer_debt()     → calls get_customer_outstanding_balance()
# db_sale.get_eod_debt_summary()  → calls get_total_debt_summary()
# SaleTab._update_debt_label()    → calls get_customer_outstanding_balance()
# ReceivableTab                   → calls all functions below
# EODTab / Dashboard              → calls get_total_debt_summary()
# =============================================================================

import sqlite3
from datetime import datetime, date

# Use the same get_db() as the rest of the app
from helpers import get_db

_WALKIN = "ลูกค้าทั่วไป"
_NO_CODE = "-"


# ─────────────────────────────────────────────────────────────
#  Internal helpers
# ─────────────────────────────────────────────────────────────

def _is_debt_sql(alias: str = "s") -> str:
    """SQL fragment: TRUE when a sale row is a debt sale.
    บิลที่ถูกยกเลิก (status='void') ไม่นับเป็นหนี้อีกต่อไป (auto-reverse ลูกหนี้)."""
    return f"""(
        ({alias}.payment_method IN ('debt', 'credit')
         OR {alias}.note LIKE '%เงิน ซื้อ%')
        AND COALESCE({alias}.status, 'normal') != 'void'
    )"""


def _outstanding_sql(alias: str = "s") -> str:
    """SQL expression: remaining balance on one sale row."""
    return f"""(
        {alias}.net
        - COALESCE({alias}.paid, 0)
        - COALESCE((
            SELECT SUM(rp.amount)
            FROM receivable_payments rp
            WHERE rp.sale_id = {alias}.id
          ), 0)
    )"""


# ─────────────────────────────────────────────────────────────
#  0. init_receivable_schema  (called once at app startup)
# ─────────────────────────────────────────────────────────────

def init_receivable_schema(db_path: str = None):
    """
    Create receivable_payments table if not exists.
    db_path ignored — uses get_db() for consistency with rest of app.
    Safe to call every startup.
    """
    sql = """
        CREATE TABLE IF NOT EXISTS receivable_payments (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            sale_id        INTEGER NOT NULL,
            customer_id    INTEGER NOT NULL DEFAULT 0,
            amount         REAL    NOT NULL,
            payment_method TEXT    DEFAULT 'เงินสด',
            note           TEXT    DEFAULT '',
            created_by     TEXT    DEFAULT '',
            paid_at        TEXT    DEFAULT (datetime('now','localtime')),
            FOREIGN KEY (sale_id) REFERENCES sales(id)
        )
    """
    try:
        conn = get_db()
        conn.execute(sql)
        conn.commit()
        conn.close()
        print("[db_receivable] ✅ receivable_payments table ready")
    except Exception as exc:
        print(f"[db_receivable] init_receivable_schema error: {exc}")


# ─────────────────────────────────────────────────────────────
#  ★ SINGLE SOURCE OF TRUTH: get_customer_outstanding_balance()
#
#  THIS is the ONE function all debt displays must call.
#  Formula: SUM(net - paid - receivable_payments) WHERE debt sale
#
#  Used by:
#    • SaleTab debt badge  (_update_debt_label)
#    • ReceivableTab customer row
#    • ReceivableTab right panel header
#    • Summary cards
#    • EOD dashboard
# ─────────────────────────────────────────────────────────────

def get_customer_outstanding_balance(customer_id: int,
                                     db_path: str = None) -> float:
    """
    ★ SINGLE SOURCE OF TRUTH for customer debt balance.
    Returns outstanding float for customer_id.
    customer_id=0 returns walk-in total.
    """
    try:
        conn = get_db()
        row = conn.execute(f"""
            SELECT COALESCE(SUM({_outstanding_sql()}), 0) AS bal
            FROM sales s
            WHERE COALESCE(s.customer_id, 0) = ?
              AND {_is_debt_sql()}
              AND {_outstanding_sql()} > 0.009
        """, (customer_id,)).fetchone()
        conn.close()
        return float(row[0]) if row else 0.0
    except Exception as exc:
        print(f"[db_receivable] get_customer_outstanding_balance error: {exc}")
        return 0.0


# ─────────────────────────────────────────────────────────────
#  ★ SINGLE SOURCE OF TRUTH: get_total_debt_summary()
#
#  Replaces get_eod_debt_summary() in db_sale.py
#  Used by EODTab and Dashboard
# ─────────────────────────────────────────────────────────────

def get_total_debt_summary(date_from: str = None,
                           date_to: str = None) -> dict:
    """
    ★ SINGLE SOURCE OF TRUTH for global debt totals.
    Replaces db_sale.get_eod_debt_summary().

    Returns:
        new_debt   — new debt created in date range
        total_debt — ALL outstanding debt across all time
        debtors    — unique customers with outstanding debt
    """
    today = date.today().isoformat()
    d0 = date_from or today
    d1 = date_to   or today

    try:
        conn = get_db()

        new_debt = conn.execute(f"""
            SELECT COALESCE(SUM({_outstanding_sql()}), 0)
            FROM sales s
            WHERE {_is_debt_sql()}
              AND DATE(s.sale_date) BETWEEN ? AND ?
              AND {_outstanding_sql()} > 0.009
        """, (d0, d1)).fetchone()[0]

        total_debt = conn.execute(f"""
            SELECT COALESCE(SUM({_outstanding_sql()}), 0)
            FROM sales s
            WHERE {_is_debt_sql()}
              AND {_outstanding_sql()} > 0.009
        """).fetchone()[0]

        debtors = conn.execute(f"""
            SELECT COUNT(DISTINCT COALESCE(s.customer_id, 0))
            FROM sales s
            WHERE {_is_debt_sql()}
              AND {_outstanding_sql()} > 0.009
              AND s.customer_id > 0
        """).fetchone()[0]

        conn.close()
        return {
            "new_debt":   float(new_debt),
            "total_debt": float(total_debt),
            "debtors":    int(debtors),
        }
    except Exception as exc:
        print(f"[db_receivable] get_total_debt_summary error: {exc}")
        return {"new_debt": 0.0, "total_debt": 0.0, "debtors": 0}


# Alias for backward compatibility with db_sale import
get_eod_debt_summary = get_total_debt_summary


# ─────────────────────────────────────────────────────────────
#  1. get_all_receivable_customers
#     Called by: receivable_tab._load_customers()
# ─────────────────────────────────────────────────────────────

def get_all_receivable_customers(search: str = "",
                                  only_overdue: bool = False,
                                  db_path: str = None) -> list:
    today = date.today().isoformat()
    like  = f"%{search.strip()}%" if search and search.strip() else None

    search_clause = ""
    params = []
    if like:
        search_clause = """
            AND (
                COALESCE(c.name,  '') LIKE ? COLLATE NOCASE
             OR COALESCE(c.phone, '') LIKE ? COLLATE NOCASE
             OR COALESCE(c.code,  '') LIKE ? COLLATE NOCASE
            )
        """
        params = [like, like, like]

    sql = f"""
        SELECT
            COALESCE(s.customer_id, 0)          AS customer_id,
            COALESCE(c.name,  '{_WALKIN}')       AS customer_name,
            COALESCE(c.phone, '')               AS phone,
            COALESCE(c.code,  '{_NO_CODE}')      AS member_code,
            COUNT(s.id)                         AS bill_count,
            SUM({_outstanding_sql()})            AS total_remaining,
            MAX(CAST(
                (JULIANDAY('{today}') - JULIANDAY(DATE(s.sale_date)))
                AS INTEGER))                    AS max_overdue_days
        FROM sales s
        LEFT JOIN customers c
            ON c.id = s.customer_id AND s.customer_id > 0
        WHERE {_is_debt_sql()}
          AND {_outstanding_sql()} > 0.009
          {search_clause}
        GROUP BY COALESCE(s.customer_id, 0)
        ORDER BY customer_name ASC
    """
    try:
        conn = get_db()
        rows = conn.execute(sql, params).fetchall()
        conn.close()
        result = []
        for r in rows:
            d = dict(r)
            d["total_remaining"]  = max(float(d["total_remaining"] or 0), 0.0)
            d["max_overdue_days"] = max(int(d["max_overdue_days"] or 0), 0)
            d["has_overdue"]      = d["max_overdue_days"] > 0
            if only_overdue and not d["has_overdue"]:
                continue
            result.append(d)
        return result
    except Exception as exc:
        print(f"[db_receivable] get_all_receivable_customers error: {exc}")
        return []


# ─────────────────────────────────────────────────────────────
#  2. get_receivable_summary
#     Called by: receivable_tab._load_summary()
# ─────────────────────────────────────────────────────────────

def get_receivable_summary(db_path: str = None) -> dict:
    today       = date.today().isoformat()
    month_start = date.today().replace(day=1).isoformat()
    try:
        conn = get_db()

        total_outstanding = conn.execute(f"""
            SELECT COALESCE(SUM({_outstanding_sql()}), 0)
            FROM sales s
            WHERE {_is_debt_sql()} AND {_outstanding_sql()} > 0.009
        """).fetchone()[0]

        row2 = conn.execute(f"""
            SELECT
                COALESCE(SUM({_outstanding_sql()}), 0)           AS total_overdue,
                COUNT(DISTINCT COALESCE(s.customer_id, 0))       AS cust_count
            FROM sales s
            WHERE {_is_debt_sql()}
              AND DATE(s.sale_date) < '{today}'
              AND {_outstanding_sql()} > 0.009
        """).fetchone()

        paid_month = conn.execute(f"""
            SELECT COALESCE(SUM(rp.amount), 0)
            FROM receivable_payments rp
            WHERE DATE(rp.paid_at) >= '{month_start}'
        """).fetchone()[0]

        conn.close()
        return {
            "total_outstanding":      float(total_outstanding),
            "total_overdue":          float(row2[0]),
            "overdue_customer_count": int(row2[1]),
            "total_paid_this_month":  float(paid_month),
        }
    except Exception as exc:
        print(f"[db_receivable] get_receivable_summary error: {exc}")
        return {"total_outstanding": 0.0, "total_overdue": 0.0,
                "overdue_customer_count": 0, "total_paid_this_month": 0.0}


# ─────────────────────────────────────────────────────────────
#  3. get_receivable_bills
#     Called by: receivable_tab._load_bills()
# ─────────────────────────────────────────────────────────────

def get_receivable_bills(customer_id: int, db_path: str = None) -> list:
    today = date.today().isoformat()
    sql = f"""
        SELECT
            s.id                     AS sale_id,
            s.id                     AS invoice_number,
            s.sale_date,
            NULL                     AS due_date,
            s.net                    AS total_amount,
            COALESCE(s.paid, 0)
            + COALESCE((SELECT SUM(rp.amount) FROM receivable_payments rp
                        WHERE rp.sale_id = s.id), 0)
                                     AS paid_amount,
            {_outstanding_sql()}     AS remaining,
            COALESCE(s.note, '')     AS note,
            s.payment_method
        FROM sales s
        WHERE COALESCE(s.customer_id, 0) = ?
          AND {_is_debt_sql()}
          AND {_outstanding_sql()} > 0.009
        ORDER BY s.sale_date ASC
    """
    try:
        conn = get_db()
        rows = conn.execute(sql, (customer_id,)).fetchall()
        conn.close()
        result = []
        for r in rows:
            d = dict(r)
            sd = (d.get("sale_date") or "")[:10]
            d["status"] = "overdue" if (sd and sd < today) else "pending"
            result.append(d)
        return result
    except Exception as exc:
        print(f"[db_receivable] get_receivable_bills error: {exc}")
        return []


# ─────────────────────────────────────────────────────────────
#  4. get_customer_balance
#     Called by: receivable_tab._on_customer_select()
# ─────────────────────────────────────────────────────────────

def get_customer_balance(customer_id: int, db_path: str = None) -> dict:
    try:
        conn = get_db()
        if customer_id and customer_id > 0:
            crow = conn.execute(
                "SELECT name FROM customers WHERE id=?", (customer_id,)
            ).fetchone()
            name = crow[0] if crow else _WALKIN
        else:
            name = _WALKIN
        conn.close()
    except Exception:
        name = _WALKIN

    return {
        "customer_name": name,
        "remaining": get_customer_outstanding_balance(customer_id),
    }


# ─────────────────────────────────────────────────────────────
#  5. get_sale_remaining_balance
#     Called by: receivable_tab._on_bill_select() etc.
# ─────────────────────────────────────────────────────────────

def get_sale_remaining_balance(sale_id: int, db_path: str = None) -> float:
    try:
        conn = get_db()
        row = conn.execute(f"""
            SELECT {_outstanding_sql()}
            FROM sales s WHERE s.id = ?
        """, (sale_id,)).fetchone()
        conn.close()
        return max(float(row[0]), 0.0) if row else 0.0
    except Exception as exc:
        print(f"[db_receivable] get_sale_remaining_balance error: {exc}")
        return 0.0


# ─────────────────────────────────────────────────────────────
#  6. add_receivable_payment
#     Called by: receivable_tab._save_payment()
# ─────────────────────────────────────────────────────────────

def add_receivable_payment(sale_id: int,
                            customer_id: int,
                            amount: float,
                            payment_method: str = "เงินสด",
                            note: str = "",
                            created_by: str = "",
                            db_path: str = None) -> dict:
    if amount <= 0:
        return {"success": False, "error": "จำนวนเงินต้องมากกว่า 0"}

    remaining_before = get_sale_remaining_balance(sale_id)
    if remaining_before <= 0:
        return {"success": False, "error": "บิลนี้ชำระครบแล้ว"}

    apply = min(amount, remaining_before)
    now   = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        conn = get_db()
        conn.execute("""
            INSERT INTO receivable_payments
              (sale_id, customer_id, amount, payment_method, note, created_by, paid_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (sale_id, customer_id, apply, payment_method, note, created_by, now))

        remaining_after = remaining_before - apply
        if remaining_after <= 0.009:
            # Mark fully settled in sales.paid so SaleTab badge also clears
            conn.execute("UPDATE sales SET paid = net WHERE id = ?", (sale_id,))

        conn.commit()
        conn.close()

        return {
            "success":    True,
            "amount_paid": apply,
            "remaining":  max(remaining_after, 0.0),
            "fully_paid": remaining_after <= 0.009,
        }
    except Exception as exc:
        print(f"[db_receivable] add_receivable_payment error: {exc}")
        return {"success": False, "error": str(exc)}


# ─────────────────────────────────────────────────────────────
#  7. get_receivable_payment_history
#     Called by: receivable_tab._load_history()
# ─────────────────────────────────────────────────────────────

def get_receivable_payment_history(customer_id: int,
                                    db_path: str = None) -> list:
    sql = """
        SELECT
            rp.paid_at,
            rp.sale_id,
            rp.sale_id            AS invoice_number,
            rp.amount,
            rp.payment_method,
            COALESCE(rp.note, '')        AS note,
            COALESCE(rp.created_by, '')  AS created_by
        FROM receivable_payments rp
        WHERE rp.customer_id = ?
        ORDER BY rp.paid_at DESC
    """
    try:
        conn = get_db()
        rows = conn.execute(sql, (customer_id,)).fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception as exc:
        print(f"[db_receivable] get_receivable_payment_history error: {exc}")
        return []


# ─────────────────────────────────────────────────────────────
#  8. get_receivable_bill_detail
#     Called by: receivable_tab._on_bill_select()
# ─────────────────────────────────────────────────────────────

def get_receivable_bill_detail(sale_id: int, db_path: str = None) -> dict:
    try:
        conn = get_db()
        srow = conn.execute("SELECT * FROM sales WHERE id=?", (sale_id,)).fetchone()
        if not srow:
            conn.close()
            return {"sale": {}, "payments": []}
        sale = dict(srow)
        sale["invoice_number"] = sale["id"]
        prows = conn.execute(
            "SELECT * FROM receivable_payments WHERE sale_id=? ORDER BY paid_at ASC",
            (sale_id,)
        ).fetchall()
        conn.close()
        return {"sale": sale, "payments": [dict(p) for p in prows]}
    except Exception as exc:
        print(f"[db_receivable] get_receivable_bill_detail error: {exc}")
        return {"sale": {}, "payments": []}
